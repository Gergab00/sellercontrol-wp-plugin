import Quagga from 'quagga'; // ES6
const Quagga = require('quagga').default; // Common JS (important: default)