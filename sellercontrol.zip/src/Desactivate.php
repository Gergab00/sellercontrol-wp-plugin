<?php
namespace SELLERCONTROL;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
