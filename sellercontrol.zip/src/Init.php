<?php
namespace SELLERCONTROL;

use SELLERCONTROL\woocommerce\WooMeta;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {
    }
}
